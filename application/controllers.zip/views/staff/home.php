<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-3"></div>
            <div class="col-lg-6 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-primary card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">person</i>
                  </div>
                  <p class="card-category">Welcome Aksess Staff</p>
                  <h3 class="card-title"> <?php
							$tgl=date('l');
							echo $tgl;
						  ?>
                    <small>/&nbsp;<?php
							$tgl=date('M d , Y');
							echo $tgl;
						  ?>
					</small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons text-success">location_city</i>Almindo Jaya Abadi
                  </div>
                </div>
              </div>
            </div>
	    <div class="col-lg-3 col-md-3 col-sm-3"></div>
</div>
