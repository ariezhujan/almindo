
<?php foreach($prospective_member as $su){
  echo "<a class='dropdown-item' href='prospective_member_view' ><i class='material-icons'>perm_contact_calendar</i>&nbsp;&nbsp;$su->company_name</a> ";
} 
?>