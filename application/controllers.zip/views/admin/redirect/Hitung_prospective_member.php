<?php
	if ($show >= 1)
	 {
	   echo "<span class='notification'>" . $show . "</div>";
	 }
  ?>