<?php
	if ($show >= 2)
	 {
	   echo "<span class='notification'>" . $show . "</div>";
	 }
  ?>