<?php
	if ($show)
	 {
	   echo "<span class='notification'>" . $show . "</div>";
	 }
  ?>